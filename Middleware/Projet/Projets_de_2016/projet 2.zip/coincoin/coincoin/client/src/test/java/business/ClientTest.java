package business;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by Dennis on 30/09/16.
 */
public class ClientTest {

    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testNouvelle_soumission() throws Exception {

    }

    @Test
    public void testObjet_vendu() throws Exception {

    }

    @Test
    public void testNouveau_prix() throws Exception {

    }

    @Test
    public void testRencherir() throws Exception {

    }

    @Test
    public void testInscription() throws Exception {

    }

    @Test
    public void testTemps_ecoule() throws Exception {

    }

    @Test
    public void testStartChrono() throws Exception {

    }

    @Test
    public void testGetUtilisateur() throws Exception {

    }

    @Test
    public void testSetUtilisateur() throws Exception {

    }

    @Test
    public void testGetEtatCourant() throws Exception {

    }

    @Test
    public void testSetEtatCourant() throws Exception {

    }

    @Test
    public void testGetChrono() throws Exception {

    }

    @Test
    public void testSetChrono() throws Exception {

    }

    @Test
    public void testGetItemCourant() throws Exception {

    }

    @Test
    public void testSetItemCourant() throws Exception {

    }

    @Test
    public void testSetPrix() throws Exception {

    }

    @Test
    public void testGetServeurVente() throws Exception {

    }

    @Test
    public void testSetServeurVente() throws Exception {

    }
}