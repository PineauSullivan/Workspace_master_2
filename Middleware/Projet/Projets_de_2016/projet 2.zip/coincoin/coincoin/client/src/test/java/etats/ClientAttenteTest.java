package etats;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Created by Dennis on 30/09/16.
 */
public class ClientAttenteTest {

    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testAction() throws Exception {

    }

    @Test
    public void testRencherir() throws Exception {

    }
}