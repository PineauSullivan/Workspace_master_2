package model;

/**
 * Created by E104607D on 28/09/16.
 */
public class ItemEnVente extends EtatItem {
    @Override
    public void action() {
        throw new UnsupportedOperationException();
    }
}
