package model;

/**
 * Created by Thibault on 27/09/16.
 * Abstract State for the ItemServer
 */
public abstract class EtatItem {
    public abstract void action();
}
